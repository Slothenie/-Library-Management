package view;

import java.util.Map;
import java.util.List;

import model.Library;
import model.User;
import model.Book;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class LibraryGUI {
    private final Library library;
    private JFrame frame;


    public LibraryGUI(Library library) {
        this.library = library;
        initialize();
    }

    private void initialize() {
        JFrame frame = new JFrame("Библиотека");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);


        JTabbedPane tabbedPane = new JTabbedPane();

        JPanel usersPanel = createUsersPanel();
        JPanel booksPanel = createBooksPanel();
        JPanel searchPanel = createSearchPanel();
        JPanel categoriesPanel = createCategoriesPanel();

        tabbedPane.addTab("Категории", categoriesPanel);
        tabbedPane.addTab("Пользователи", usersPanel);
        tabbedPane.addTab("Книги", booksPanel);
        tabbedPane.addTab("Поиск", searchPanel);

        JButton testButton = new JButton("Запуск тестов");
        testButton.addActionListener(e -> runTests());
        frame.getContentPane().add(testButton, BorderLayout.SOUTH);

        frame.add(tabbedPane);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private JPanel createUsersPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        DefaultTableModel userModel = new DefaultTableModel(new String[]{"ID", "Имя"}, 0);
        JTable userTable = new JTable(userModel);
        JScrollPane scrollPane = new JScrollPane(userTable);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton addUserButton = new JButton("Добавить пользователя");
        JButton deleteUserButton = new JButton("Удалить пользователя");
        JButton refreshButton = new JButton("Обновить");


        buttonPanel.add(addUserButton);
        buttonPanel.add(deleteUserButton);
        buttonPanel.add(refreshButton);

        panel.add(buttonPanel, BorderLayout.SOUTH);


        addUserButton.addActionListener(e -> {
            String userName = JOptionPane.showInputDialog("Введите имя пользователя:");
            if (userName != null && !userName.trim().isEmpty()) {
                library.addUser(userName);
                JOptionPane.showMessageDialog(null, "Пользователь добавлен!");
                refreshUsersTable(userModel);
            }
        });


        deleteUserButton.addActionListener(e -> {
            String userIdStr = JOptionPane.showInputDialog("Введите ID пользователя для удаления:");
            try {
                int userId = Integer.parseInt(userIdStr);
                library.removeUserById(userId);
                JOptionPane.showMessageDialog(null, "Пользователь удалён!");
                refreshUsersTable(userModel);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Введите корректный ID.", "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        });


        refreshButton.addActionListener(e -> refreshUsersTable(userModel));

        refreshUsersTable(userModel);
        return panel;
    }

    private JPanel createSearchPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel userSearchPanel = new JPanel();
        userSearchPanel.setLayout(new FlowLayout());

        JLabel userLabel = new JLabel("Поиск пользователя:");
        JTextField userSearchField = new JTextField(20);
        JButton userSearchButton = new JButton("Найти");

        userSearchPanel.add(userLabel);
        userSearchPanel.add(userSearchField);
        userSearchPanel.add(userSearchButton);

        JPanel bookSearchPanel = new JPanel();
        bookSearchPanel.setLayout(new FlowLayout());

        JLabel bookLabel = new JLabel("Поиск книги:");
        JTextField bookSearchField = new JTextField(20);
        JButton bookSearchButton = new JButton("Найти");

        bookSearchPanel.add(bookLabel);
        bookSearchPanel.add(bookSearchField);
        bookSearchPanel.add(bookSearchButton);

        panel.add(userSearchPanel, BorderLayout.NORTH);
        panel.add(bookSearchPanel, BorderLayout.CENTER);

        userSearchButton.addActionListener(e -> searchUser(userSearchField.getText()));
        bookSearchButton.addActionListener(e -> searchBook(bookSearchField.getText()));

        return panel;
    }




    private JPanel createBooksPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        DefaultTableModel bookModel = new DefaultTableModel(new String[]{"ID", "Название", "Автор", "Категория", "Доступность"}, 0);

        JTable bookTable = new JTable(bookModel);
        JScrollPane scrollPane = new JScrollPane(bookTable);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton addBookButton = new JButton("Добавить книгу");
        JButton deleteBookButton = new JButton("Удалить книгу");
        JButton issueBookButton = new JButton("Выдать книгу");
        JButton returnBookButton = new JButton("Вернуть книгу");
        JButton refreshButton = new JButton("Обновить");

        JButton assignCategoryButton = new JButton("Назначить категорию");
        buttonPanel.add(assignCategoryButton);


        buttonPanel.add(addBookButton);
        buttonPanel.add(deleteBookButton);
        buttonPanel.add(issueBookButton);
        buttonPanel.add(returnBookButton);
        buttonPanel.add(refreshButton);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        addBookButton.addActionListener(e -> {
            String bookTitle = JOptionPane.showInputDialog("Введите название книги:");
            String bookAuthor = JOptionPane.showInputDialog("Введите автора книги:");
            if (bookTitle != null && !bookTitle.trim().isEmpty() && bookAuthor != null && !bookAuthor.trim().isEmpty()) {
                library.addBook(bookTitle, bookAuthor);
                JOptionPane.showMessageDialog(null, "Книга добавлена!");
                refreshBooksTable(bookModel);
            }
        });

        deleteBookButton.addActionListener(e -> {
            String bookIdStr = JOptionPane.showInputDialog("Введите ID книги для удаления:");
            try {
                int bookId = Integer.parseInt(bookIdStr);
                library.removeBookById(bookId);
                JOptionPane.showMessageDialog(null, "Книга удалена!");
                refreshBooksTable(bookModel);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Введите корректный ID.", "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        });

        issueBookButton.addActionListener(e -> {
            String bookIdStr = JOptionPane.showInputDialog("Введите ID книги:");
            String userIdStr = JOptionPane.showInputDialog("Введите ID пользователя:");
            try {
                int bookId = Integer.parseInt(bookIdStr);
                int userId = Integer.parseInt(userIdStr);
                library.lendBookToUser(bookId, userId);
                JOptionPane.showMessageDialog(null, "Книга выдана!");
                refreshBooksTable(bookModel);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Введите корректные ID.", "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        });

        returnBookButton.addActionListener(e -> {
            String bookIdStr = JOptionPane.showInputDialog("Введите ID книги для возврата:");
            try {
                int bookId = Integer.parseInt(bookIdStr);
                library.returnBookFromUser(bookId);
                JOptionPane.showMessageDialog(null, "Книга возвращена!");
                refreshBooksTable(bookModel);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Введите корректный ID.", "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        });

        assignCategoryButton.addActionListener(e -> {
            String bookIdStr = JOptionPane.showInputDialog("Введите ID книги:");
            if (bookIdStr == null || bookIdStr.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "ID книги не введён.", "Ошибка", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                int bookId = Integer.parseInt(bookIdStr);
                List<Map<String, String>> categories = library.getCategories();
                if (categories.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Категории отсутствуют. Сначала добавьте категорию.");
                    return;
                }

                String[] categoryOptions = categories.stream()
                        .map(category -> category.get("name"))
                        .toArray(String[]::new);

                String selectedCategory = (String) JOptionPane.showInputDialog(
                        null,
                        "Выберите категорию:",
                        "Назначение категории",
                        JOptionPane.PLAIN_MESSAGE,
                        null,
                        categoryOptions,
                        categoryOptions[0]
                );

                if (selectedCategory != null) {
                    int categoryId = categories.stream()
                            .filter(category -> category.get("name").equals(selectedCategory))
                            .findFirst()
                            .map(category -> Integer.parseInt(category.get("id")))
                            .orElseThrow();

                    library.assignCategoryToBook(bookId, categoryId);
                    JOptionPane.showMessageDialog(null, "Категория назначена книге!");
                    refreshBooksTable(bookModel);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Введите корректный ID книги.", "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        });


        refreshButton.addActionListener(e -> refreshBooksTable(bookModel));

        refreshBooksTable(bookModel);
        return panel;
    }

    private JPanel createCategoriesPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JButton showCategoriesButton = new JButton("Показать категории");
        showCategoriesButton.addActionListener(e -> showCategories());

        JPanel addCategoryPanel = new JPanel(new FlowLayout());
        JTextField categoryField = new JTextField(20);
        JButton addCategoryButton = new JButton("Добавить категорию");

        addCategoryButton.addActionListener(e -> {
            String categoryName = categoryField.getText().trim();
            if (categoryName.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Введите название категории.");
                return;
            }
            library.addCategory(categoryName);
            JOptionPane.showMessageDialog(frame, "Категория добавлена.");
            categoryField.setText("");
        });

        addCategoryPanel.add(new JLabel("Название категории:"));
        addCategoryPanel.add(categoryField);
        addCategoryPanel.add(addCategoryButton);

        panel.add(showCategoriesButton, BorderLayout.NORTH);
        panel.add(addCategoryPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void showCategories() {
        List<Map<String, String>> categories = library.getCategories();
        if (categories.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Категории отсутствуют.");
            return;
        }

        DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Название"}, 0);
        for (Map<String, String> category : categories) {
            model.addRow(new Object[]{
                    category.get("id"),
                    category.get("name")
            });
        }

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        JDialog dialog = new JDialog(frame, "Список категорий", true);
        dialog.setSize(400, 300);
        dialog.add(scrollPane);
        dialog.setLocationRelativeTo(frame);
        dialog.setVisible(true);
    }



    private void refreshUsersTable(DefaultTableModel userModel) {
        userModel.setRowCount(0);
        List<User> users = library.getAllUsers();
        for (User user : users) {
            userModel.addRow(new Object[]{user.getId(), user.getName()});
        }
    }

    private void refreshBooksTable(DefaultTableModel bookModel) {
        bookModel.setRowCount(0);
        List<Map<String, String>> booksWithCategories = library.getBooksWithCategories();

        for (Map<String, String> book : booksWithCategories) {
            bookModel.addRow(new Object[]{
                    book.get("id"),
                    book.get("title"),
                    book.get("author"),
                    book.get("category") == null ? "Нет категории" : book.get("category"),
                    book.get("availability").equals("true") ? "Доступна" : "Выдана"
            });
        }
    }


    private void runTests() {
        library.addUser("test name 1");
        library.addUser("test name 2");
        library.addBook("test book 2", "author 1");
        library.addBook("test book 3", "author 2");

        JOptionPane.showMessageDialog(null, "Тестовые данные добавлены.");
    }

    private void showBooksTable() {
        List<Map<String, String>> booksWithUsers = library.getBooksWithUsers();
        if (booksWithUsers.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Нет книг в библиотеке.");
            return;
        }

        DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Название", "Автор", "Пользователь"}, 0);
        for (Map<String, String> book : booksWithUsers) {
            model.addRow(new Object[]{
                    book.get("id"),
                    book.get("title"),
                    book.get("author"),
                    book.get("user")
            });
        }

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        JDialog dialog = new JDialog(frame, "Список книг", true);
        dialog.setSize(600, 400);
        dialog.add(scrollPane);
        dialog.setLocationRelativeTo(frame);
        dialog.setVisible(true);
    }

    private void searchUser(String query) {
        if (query.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Введите имя пользователя для поиска.");
            return;
        }

        List<String> users = library.searchUsers(query);
        if (users.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Пользователи не найдены.");
            return;
        }

        StringBuilder result = new StringBuilder("Найденные пользователи:\n");
        for (String user : users) {
            result.append("- ").append(user).append("\n");
        }

        JOptionPane.showMessageDialog(frame, result.toString());
    }

    private void searchBook(String query) {
        if (query.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Введите название книги или имя автора для поиска.");
            return;
        }

        List<Map<String, String>> books = library.searchBooks(query);
        if (books.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Книги не найдены.");
            return;
        }

        StringBuilder result = new StringBuilder("Найденные книги:\n");
        for (Map<String, String> book : books) {
            result.append("- Название: ").append(book.get("title"))
                    .append(", Автор: ").append(book.get("author"))
                    .append("\n");
        }

        JOptionPane.showMessageDialog(frame, result.toString());
    }



}
