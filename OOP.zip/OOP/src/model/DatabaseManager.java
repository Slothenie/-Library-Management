package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;


public class DatabaseManager {
    private static final String URL = "jdbc:postgresql://localhost:5432/OOP_base";
    private static final String USER = "postgres";
    private static final String PASSWORD = "KarHub693";

    static {
        try {
            Class.forName("org.postgresql.Driver");
            initDatabase();
        } catch (ClassNotFoundException e) {
            System.err.println("Ошибка: драйвер PostgreSQL не найден.");
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void initDatabase() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS users (
                    id SERIAL PRIMARY KEY,
                    name VARCHAR(255) UNIQUE NOT NULL
                )
            """);
            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS books (
                    id SERIAL PRIMARY KEY,
                    title VARCHAR(255) UNIQUE NOT NULL,
                    author VARCHAR(255) NOT NULL,
                    is_available BOOLEAN DEFAULT TRUE,
                    user_id INT,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
                )
            """);
        } catch (SQLException e) {
            System.err.println("Ошибка при инициализации базы данных: " + e.getMessage());
        }
    }

    public static List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM users;")) {
            while (rs.next()) {
                users.add(new User(rs.getInt("id"), rs.getString("name")));
            }
        } catch (SQLException e) {
            System.err.println("Ошибка при получении пользователей: " + e.getMessage());
        }
        return users;
    }

    public static List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM books;")) {
            while (rs.next()) {
                books.add(new Book(rs.getInt("id"), rs.getString("title"), rs.getString("author"),
                        rs.getBoolean("is_available"), rs.getInt("user_id")));
            }
        } catch (SQLException e) {
            System.err.println("Ошибка при получении книг: " + e.getMessage());
        }
        return books;
    }
    public static List<Map<String, String>> getBooksWithUsers() {
        List<Map<String, String>> booksWithUsers = new ArrayList<>();
        String query = """
        SELECT books.id AS book_id, books.title, books.author, 
               CASE WHEN users.name IS NOT NULL THEN users.name ELSE 'Доступна' END AS user_name
        FROM books
        LEFT JOIN users ON books.user_id = users.id;
    """;

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Map<String, String> bookInfo = new HashMap<>();
                bookInfo.put("id", String.valueOf(rs.getInt("book_id")));
                bookInfo.put("title", rs.getString("title"));
                bookInfo.put("author", rs.getString("author"));
                bookInfo.put("user", rs.getString("user_name"));
                booksWithUsers.add(bookInfo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return booksWithUsers;
    }


    public static void addUser(String name) {
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO users (name) VALUES (?) ON CONFLICT DO NOTHING")) {
            pstmt.setString(1, name);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Ошибка при добавлении пользователя: " + e.getMessage());
        }
    }

    public static void addBook(String title, String author) {
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO books (title, author) VALUES (?, ?) ON CONFLICT DO NOTHING")) {
            pstmt.setString(1, title);
            pstmt.setString(2, author);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Ошибка при добавлении книги: " + e.getMessage());
        }
    }

    public static void deleteBook(int bookId) {
        String query = "DELETE FROM books WHERE id = ?;";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, bookId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Ошибка при удалении книги: " + e.getMessage());
        }
    }

    public static void deleteUser(int userId) {
        String query = "DELETE FROM users WHERE id = ?;";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Пользователь с ID " + userId + " успешно удалён.");
            } else {
                System.out.println("Пользователь с ID " + userId + " не найден.");
            }
        } catch (SQLException e) {
            System.err.println("Ошибка при удалении пользователя: " + e.getMessage());
        }
    }


    public static void lendBook(int bookId, int userId) {
        String query = "UPDATE books SET is_available = FALSE, user_id = ? WHERE id = ? AND is_available = TRUE;";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            pstmt.setInt(2, bookId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Ошибка при выдаче книги: " + e.getMessage());
        }
    }

    public static void returnBook(int bookId) {
        String query = "UPDATE books SET is_available = TRUE, user_id = NULL WHERE id = ?;";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, bookId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Ошибка при возврате книги: " + e.getMessage());
        }
    }

    public static void addCategory(String name) {
        String sql = "INSERT INTO categories (name) VALUES (?) ON CONFLICT (name) DO NOTHING";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static List<Map<String, String>> getBooksWithCategories() {
        List<Map<String, String>> books = new ArrayList<>();
        String sql = """
        SELECT b.id, b.title, b.author, c.name AS category, b.is_available AS availability
        FROM books b
        LEFT JOIN categories c ON b.category_id = c.id
    """;

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Map<String, String> book = new HashMap<>();
                book.put("id", String.valueOf(rs.getInt("id")));
                book.put("title", rs.getString("title"));
                book.put("author", rs.getString("author"));
                book.put("category", rs.getString("category"));
                book.put("availability", String.valueOf(rs.getBoolean("availability")));
                books.add(book);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return books;
    }

    public static void assignCategoryToBook(int bookId, int categoryId) {
        String sql = "UPDATE books SET category_id = ? WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, categoryId);
            stmt.setInt(2, bookId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }




    public static List<String> searchUsers(String query) {
        List<String> users = new ArrayList<>();
        String sql = "SELECT name FROM users WHERE name ILIKE ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + query + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                users.add(rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return users;
    }

    public static List<Map<String, String>> searchBooks(String query) {
        List<Map<String, String>> books = new ArrayList<>();
        String sql = """
        SELECT title, author FROM books 
        WHERE title ILIKE ? OR author ILIKE ?
    """;

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + query + "%");
            stmt.setString(2, "%" + query + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Map<String, String> book = new HashMap<>();
                book.put("title", rs.getString("title"));
                book.put("author", rs.getString("author"));
                books.add(book);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return books;
    }

    public static List<Map<String, String>> getCategories() {
        List<Map<String, String>> categories = new ArrayList<>();
        String sql = "SELECT id, name FROM categories";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Map<String, String> category = new HashMap<>();
                category.put("id", String.valueOf(rs.getInt("id")));
                category.put("name", rs.getString("name"));
                categories.add(category);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return categories;
    }



}
