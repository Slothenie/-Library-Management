package model;

public class Book {
    private int id;
    private String title;
    private String author;
    private boolean isAvailable;
    private Integer userId;

    public Book(int id, String title, String author, boolean isAvailable, Integer userId) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.isAvailable = isAvailable;
        this.userId = userId;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
}
