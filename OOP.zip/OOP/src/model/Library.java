package model;

import java.util.List;
import java.util.Map;

public class Library {
    public void initSampleData() {
        DatabaseManager.addUser("Иван Иванов");
        DatabaseManager.addUser("Мария Петрова");
        DatabaseManager.addBook("Война и мир", "Лев Толстой");
        DatabaseManager.addBook("Преступление и наказание", "Фёдор Достоевский");
    }

    public void showAllUsers() {
        System.out.println("Пользователи:");
        DatabaseManager.getAllUsers().forEach(user ->
                System.out.println("ID: " + user.getId() + ", Имя: " + user.getName())
        );
    }

    public void addUser(String name) {
        DatabaseManager.addUser(name);
    }

    public void showAllBooks() {
        System.out.println("Книги:");
        DatabaseManager.getAllBooks().forEach(book ->
                System.out.println("ID: " + book.getId() + ", Название: " + book.getTitle() +
                        ", Автор: " + book.getAuthor() + ", Доступность: " +
                        (book.isAvailable() ? "Доступна" : "Выдана"))
        );
    }

    public void addBook(String title, String author) {
        DatabaseManager.addBook(title, author);
    }

    public void removeBookById(int id) {
        DatabaseManager.deleteBook(id);
    }

    public void lendBookToUser(int bookId, int userId) {
        DatabaseManager.lendBook(bookId, userId);
    }

    public void returnBookFromUser(int bookId) {
        DatabaseManager.returnBook(bookId);
    }
    public void removeUserById(int id) {
        DatabaseManager.deleteUser(id);
    }

    public void addCategory(String name) {
        DatabaseManager.addCategory(name);
    }

    public List<Map<String, String>> getCategories() {
        return DatabaseManager.getCategories();
    }


    public List<User> getAllUsers() {
        return DatabaseManager.getAllUsers();
    }

    public List<Book> getAllBooks() {
        return DatabaseManager.getAllBooks();
    }

    public List<Map<String, String>> getBooksWithUsers() {
        return DatabaseManager.getBooksWithUsers();
    }

    public List<String> searchUsers(String query) {
        return DatabaseManager.searchUsers(query);
    }

    public List<Map<String, String>> searchBooks(String query) {
        return DatabaseManager.searchBooks(query);
    }

    public List<Map<String, String>> getBooksWithCategories() {
        return DatabaseManager.getBooksWithCategories();
    }

    public void assignCategoryToBook(int bookId, int categoryId) {
        DatabaseManager.assignCategoryToBook(bookId, categoryId);
    }



}
