package Main;

import model.Library;
import view.LibraryGUI;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        library.initSampleData();

        javax.swing.SwingUtilities.invokeLater(() -> new LibraryGUI(library));


        System.out.println("Консольный режим:");
        library.showAllUsers();
        library.showAllBooks();
    }
}
